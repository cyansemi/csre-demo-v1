#!/bin/bash
rm testdata/large/packet*.txt
